CREATE TABLE IF NOT EXISTS public.ticket
(
    id_ticket integer NOT NULL,
    id_vaga integer,
    data date,
    hora_ini integer,
    hora_fin integer,
    preco integer,
    pago boolean,
    CONSTRAINT "Ticket_pkey" PRIMARY KEY (id_ticket),
    CONSTRAINT id_vaga FOREIGN KEY (id_vaga)
        REFERENCES public.vaga (id_vaga) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);
CREATE TABLE IF NOT EXISTS public.vaga
(
    id_vaga integer NOT NULL,
    id_veiculo integer,
    descricao character varying COLLATE pg_catalog."default",
    ocupada boolean,
    CONSTRAINT vaga_pkey PRIMARY KEY (id_vaga),
    CONSTRAINT id_veiculo FOREIGN KEY (id_veiculo)
        REFERENCES public.veiculo (id_veiculo) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);
CREATE TABLE IF NOT EXISTS public.veiculo
(
    id_veiculo integer NOT NULL,
    id_mensalista integer,
    eh_mensalista boolean,
    placa character varying(20) COLLATE pg_catalog."default",
    marca character varying(20) COLLATE pg_catalog."default",
    modelo character varying(20) COLLATE pg_catalog."default",
    cor character varying(10) COLLATE pg_catalog."default",
    CONSTRAINT "Veiculo_pkey" PRIMARY KEY (id_veiculo),
    CONSTRAINT id_mensalista FOREIGN KEY (id_mensalista)
        REFERENCES public.mensalista (id_mensalista) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
        NOT VALID
);
CREATE TABLE IF NOT EXISTS public.mensalista
(
    id_mensalista integer NOT NULL,
    nome character varying(20) COLLATE pg_catalog."default",
    cpf integer NOT NULL,
    telefone integer,
    em_dia boolean,
    CONSTRAINT mensalista_pkey PRIMARY KEY (id_mensalista)
);
